<?php 
header("Location: kernel/logout.php");
?>