<?php 
session_start();
include_once("kernel/configs.php");


?>