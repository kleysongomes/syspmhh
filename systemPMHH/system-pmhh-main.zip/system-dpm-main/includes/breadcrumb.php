
 <!-- BREADCRUMB-->
 <section class="au-breadcrumb m-t-75">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="au-breadcrumb-content">
                                    <div class="au-breadcrumb-left">
                                        <span class="au-breadcrumb-span"  style='color: black;'><i class="fa fa-info"></i> Lembrete: </span>
                                        <ul class="list-unstyled list-inline au-breadcrumb__list">
                                            <li class="list-inline-item active"  style='color: black;'>
                                            <?php
$a=array("A suprema arte da guerra é derrotar o inimigo sem lutar."=>"A suprema arte da guerra é derrotar o inimigo sem lutar.",
"A sorte sorri para os audaciosos."=>"A sorte sorri para os audaciosos.",
"Vença pelas suas atitudes, nunca discuta."=>"Vença pelas suas atitudes, nunca discuta.",
"Aquele que ousa, vence."=>"Aquele que ousa, vence.",
"Sentido = silêncio! Fale apenas quando permitido."=>"Sentido = silêncio! Fale apenas quando permitido.",
"Em caso de dúvidas, pergunte aos seus superiores."=>"Em caso de dúvidas, pergunte aos seus superiores.",
"Respeito é virtude de almas elegantes. Faça uso dela."=>"Respeito é virtude de almas elegantes. Faça uso dela.",
);
print_r(array_rand($a,1));
?>
                                            </li>
                                        </ul>
                                    </div>
                                  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END BREADCRUMB-->

