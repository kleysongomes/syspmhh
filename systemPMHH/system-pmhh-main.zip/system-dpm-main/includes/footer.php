            <section>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="copyright">
                                <p>Desenvolvido <i class="fa fa-code"></i> com <i class="fa fa-heart"></i> por <a target="_blank" href="https://github.com/the1scient">theGuiihBR</a>. Base por Colorlib.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>