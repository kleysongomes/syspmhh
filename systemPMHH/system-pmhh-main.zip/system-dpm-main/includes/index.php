<?php 
header('Location: ../painel.php');
?>